from django.contrib import admin
from .models import url

admin.site.register(url)