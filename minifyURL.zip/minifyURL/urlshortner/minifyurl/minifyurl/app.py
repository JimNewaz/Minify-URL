from django.apps import AppConfig

class minifyurlConfig(AppConfig):
    name = 'minifyurl'